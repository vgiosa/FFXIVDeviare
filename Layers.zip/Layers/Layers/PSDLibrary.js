﻿var Renderer = (function () {
    function Renderer(width, height) {
        this.layers = new Array();
        this.width = width;
        this.height = height;
        this.canvas = document.createElement("canvas");
        this.canvas.width = this.width;
        this.canvas.height = this.height;
        document.body.appendChild(this.canvas);
    }
    Renderer.prototype.addLayer = function () {
        var layer = new Layer(this.width, this.height);
        layer.imageData = this.canvas.getContext("2d").createImageData(this.width, this.height);
        layer.drawRandomColorBar(this.layers.length);
        this.layers.push(layer);
        layer.opacity = 127;
    };

    Renderer.prototype.render = function () {
        var renderData = this.canvas.getContext("2d").createImageData(this.width, this.height);
        for (var il = 0; il < this.layers.length; il++) {
            var layer = this.layers[il];

            if (!layer.visible)
                continue;
            for (var iy = 0; iy < this.height; iy++) {
                for (var ix = 0; ix < this.width; ix++) {
                    var i = (iy * this.width + ix) * 4;
                    if (layer.imageData.data[i + 3] != 0) {
                        if ((layer.opacity == 255 && layer.imageData.data[i + 3] == 255)) {
                            renderData.data[i] = layer.imageData.data[i];
                            renderData.data[i + 1] = layer.imageData.data[i + 1];
                            renderData.data[i + 2] = layer.imageData.data[i + 2];
                            renderData.data[i + 3] = layer.imageData.data[i + 3];
                        } else {
                            var dstA = renderData.data[i] / 255;
                            var srcA = ((layer.opacity + layer.imageData.data[i + 3]) / 2) / 255;
                            var dstR = renderData.data[i];
                            var srcR = layer.imageData.data[i];
                            var dstB = renderData.data[i + 1];
                            var srcB = layer.imageData.data[i + 1];
                            var dstG = renderData.data[i + 2];
                            var srcG = layer.imageData.data[i + 2];
                            var outA = srcA + dstA * (1 - srcA);
                            renderData.data[i] = (srcR * srcA + dstR * dstA * (1 - srcA)) / outA;
                            renderData.data[i + 1] = (srcG * srcA + dstG * dstA * (1 - srcA)) / outA;
                            renderData.data[i + 2] = (srcB * srcA + dstB * dstA * (1 - srcA)) / outA;
                            renderData.data[i + 3] = outA * 255;
                        }
                    }
                }
            }
        }

        this.canvas.getContext("2d").putImageData(renderData, 0, 0);
    };
    return Renderer;
})();
var renderer;
window.onload = function () {
    var loader = new PSD.PsdLoader();

    document.getElementById("psdBox").onchange = loader.loadPSD;
    /*
    renderer = new Renderer(4000, 3000);
    renderer.addLayer();
    renderer.addLayer();
    renderer.addLayer();
    renderer.addLayer();
    renderer.addLayer();
    renderer.addLayer();
    renderer.addLayer();
    renderer.addLayer();
    renderer.addLayer();
    renderer.addLayer();
    renderer.layers[6].visible = false;
    renderer.render();
    */
};
var Layer = (function () {
    function Layer(width, height) {
        this.visible = true;
        this.opacity = 255;
        this.width = width;
        this.height = height;
    }
    /*mock data function*/
    Layer.prototype.drawRandomColorBar = function (offset) {
        var r = Math.random() * 255;
        var g = Math.random() * 255;
        var b = Math.random() * 255;
        for (var iy = 0; iy < this.height; iy++) {
            for (var ix = 0 + (offset * 20); ix < 60 + (offset * 20); ix++) {
                var i = (iy * this.width + ix) * 4;
                this.imageData.data[i] = r;
                this.imageData.data[i + 1] = g;
                this.imageData.data[i + 2] = b;
                this.imageData.data[i + 3] = 255;
            }
        }
    };
    return Layer;
})();
var __extends = this.__extends || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var AlphaChannelNames = (function (_super) {
            __extends(AlphaChannelNames, _super);
            function AlphaChannelNames() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1006;
            }
            return AlphaChannelNames;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var AlphaIdentifiers = (function (_super) {
            __extends(AlphaIdentifiers, _super);
            function AlphaIdentifiers() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1053;
            }
            return AlphaIdentifiers;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var AlternateSpotColors = (function (_super) {
            __extends(AlternateSpotColors, _super);
            function AlternateSpotColors() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1067;
            }
            return AlternateSpotColors;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var AutoSaveFilePath = (function (_super) {
            __extends(AutoSaveFilePath, _super);
            function AutoSaveFilePath() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1086;
            }
            return AutoSaveFilePath;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var AutoSaveFormat = (function (_super) {
            __extends(AutoSaveFormat, _super);
            function AutoSaveFormat() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1087;
            }
            return AutoSaveFormat;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var BackgroundColor = (function (_super) {
            __extends(BackgroundColor, _super);
            function BackgroundColor() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1010;
            }
            return BackgroundColor;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var Borderinformation = (function (_super) {
            __extends(Borderinformation, _super);
            function Borderinformation() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1009;
            }
            return Borderinformation;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var CaptionDigest = (function (_super) {
            __extends(CaptionDigest, _super);
            function CaptionDigest() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1061;
            }
            return CaptionDigest;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var CaptionPascalString = (function (_super) {
            __extends(CaptionPascalString, _super);
            function CaptionPascalString() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1008;
            }
            return CaptionPascalString;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var ClippingPathName = (function (_super) {
            __extends(ClippingPathName, _super);
            function ClippingPathName() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 2999;
            }
            return ClippingPathName;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var ColorHalftoning = (function (_super) {
            __extends(ColorHalftoning, _super);
            function ColorHalftoning() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1013;
            }
            return ColorHalftoning;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var ColorSamplersResource = (function (_super) {
            __extends(ColorSamplersResource, _super);
            function ColorSamplersResource() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1073;
            }
            return ColorSamplersResource;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var ColorTransferFunctions = (function (_super) {
            __extends(ColorTransferFunctions, _super);
            function ColorTransferFunctions() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1016;
            }
            return ColorTransferFunctions;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var CopyrightFlag = (function (_super) {
            __extends(CopyrightFlag, _super);
            function CopyrightFlag() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1034;
            }
            return CopyrightFlag;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var CopyrightURL = (function (_super) {
            __extends(CopyrightURL, _super);
            function CopyrightURL() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1035;
            }
            return CopyrightURL;
        })(ImageBlockDefinitions.ImageResourceBlock);
        ImageBlockDefinitions.CopyrightURL = CopyrightURL;
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var CountInformation = (function (_super) {
            __extends(CountInformation, _super);
            function CountInformation() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1080;
            }
            return CountInformation;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var DeprecatedColorSamplersResource = (function (_super) {
            __extends(DeprecatedColorSamplersResource, _super);
            function DeprecatedColorSamplersResource() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1038;
            }
            return DeprecatedColorSamplersResource;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var DeprecatedDisplayInfo = (function (_super) {
            __extends(DeprecatedDisplayInfo, _super);
            function DeprecatedDisplayInfo() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1007;
            }
            return DeprecatedDisplayInfo;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var DeprecatedThumbnailResource = (function (_super) {
            __extends(DeprecatedThumbnailResource, _super);
            function DeprecatedThumbnailResource() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1033;
            }
            return DeprecatedThumbnailResource;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var DisplayInfoStructureFloatingPoint = (function (_super) {
            __extends(DisplayInfoStructureFloatingPoint, _super);
            function DisplayInfoStructureFloatingPoint() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1077;
            }
            return DisplayInfoStructureFloatingPoint;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var DocumentSpecificIDsSeedNumber = (function (_super) {
            __extends(DocumentSpecificIDsSeedNumber, _super);
            function DocumentSpecificIDsSeedNumber() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1044;
            }
            return DocumentSpecificIDsSeedNumber;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var DuotoneHalftoning = (function (_super) {
            __extends(DuotoneHalftoning, _super);
            function DuotoneHalftoning() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1014;
            }
            return DuotoneHalftoning;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var DuotoneImageInformation = (function (_super) {
            __extends(DuotoneImageInformation, _super);
            function DuotoneImageInformation() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1018;
            }
            return DuotoneImageInformation;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var DuotoneTransferFunctions = (function (_super) {
            __extends(DuotoneTransferFunctions, _super);
            function DuotoneTransferFunctions() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1017;
            }
            return DuotoneTransferFunctions;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var EffectsVisible = (function (_super) {
            __extends(EffectsVisible, _super);
            function EffectsVisible() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1042;
            }
            return EffectsVisible;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var EPSOptions = (function (_super) {
            __extends(EPSOptions, _super);
            function EPSOptions() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1021;
            }
            return EPSOptions;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var EXIFData1 = (function (_super) {
            __extends(EXIFData1, _super);
            function EXIFData1() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1058;
            }
            return EXIFData1;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var EXIFData3 = (function (_super) {
            __extends(EXIFData3, _super);
            function EXIFData3() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1059;
            }
            return EXIFData3;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var GlobalAltitude = (function (_super) {
            __extends(GlobalAltitude, _super);
            function GlobalAltitude() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1049;
            }
            return GlobalAltitude;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var GlobalAngle = (function (_super) {
            __extends(GlobalAngle, _super);
            function GlobalAngle() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1037;
            }
            return GlobalAngle;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var GrayscaleHalftoning = (function (_super) {
            __extends(GrayscaleHalftoning, _super);
            function GrayscaleHalftoning() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1012;
            }
            return GrayscaleHalftoning;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var GrayscaleMultichannelTransferFunction = (function (_super) {
            __extends(GrayscaleMultichannelTransferFunction, _super);
            function GrayscaleMultichannelTransferFunction() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1015;
            }
            return GrayscaleMultichannelTransferFunction;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var GridAndGuidesInformation = (function (_super) {
            __extends(GridAndGuidesInformation, _super);
            function GridAndGuidesInformation() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1032;
            }
            return GridAndGuidesInformation;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var HDRToningInformation = (function (_super) {
            __extends(HDRToningInformation, _super);
            function HDRToningInformation() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1070;
            }
            return HDRToningInformation;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var ICCProfile = (function (_super) {
            __extends(ICCProfile, _super);
            function ICCProfile() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1039;
            }
            return ICCProfile;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var ICCUntaggedProfile = (function (_super) {
            __extends(ICCUntaggedProfile, _super);
            function ICCUntaggedProfile() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1041;
            }
            return ICCUntaggedProfile;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var ImageMode = (function (_super) {
            __extends(ImageMode, _super);
            function ImageMode() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1029;
            }
            return ImageMode;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var ImageReadyDataSets = (function (_super) {
            __extends(ImageReadyDataSets, _super);
            function ImageReadyDataSets() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 7001;
            }
            return ImageReadyDataSets;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var ImageReadyVariables = (function (_super) {
            __extends(ImageReadyVariables, _super);
            function ImageReadyVariables() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 7000;
            }
            return ImageReadyVariables;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        (function (ImageResourceIdentifier) {
            ImageResourceIdentifier[ImageResourceIdentifier["MacPrintMangerInfo"] = 1001] = "MacPrintMangerInfo";
            ImageResourceIdentifier[ImageResourceIdentifier["ResolutionInfo"] = 1005] = "ResolutionInfo";
            ImageResourceIdentifier[ImageResourceIdentifier["AlphaChannelNames"] = 1006] = "AlphaChannelNames";
            ImageResourceIdentifier[ImageResourceIdentifier["DeprecatedDisplayInfo"] = 1007] = "DeprecatedDisplayInfo";
            ImageResourceIdentifier[ImageResourceIdentifier["CaptionPascalString"] = 1008] = "CaptionPascalString";
            ImageResourceIdentifier[ImageResourceIdentifier["Borderinformation"] = 1009] = "Borderinformation";
            ImageResourceIdentifier[ImageResourceIdentifier["BackgroundColor"] = 1010] = "BackgroundColor";
            ImageResourceIdentifier[ImageResourceIdentifier["PrintFlags"] = 1011] = "PrintFlags";
            ImageResourceIdentifier[ImageResourceIdentifier["GrayscaleHalftoning"] = 1012] = "GrayscaleHalftoning";
            ImageResourceIdentifier[ImageResourceIdentifier["ColorHalftoning"] = 1013] = "ColorHalftoning";
            ImageResourceIdentifier[ImageResourceIdentifier["DuotoneHalftoning"] = 1014] = "DuotoneHalftoning";
            ImageResourceIdentifier[ImageResourceIdentifier["GrayscaleMultichannelTransferFunction"] = 1015] = "GrayscaleMultichannelTransferFunction";
            ImageResourceIdentifier[ImageResourceIdentifier["ColorTransferFunctions"] = 1016] = "ColorTransferFunctions";
            ImageResourceIdentifier[ImageResourceIdentifier["DuotoneTransferFunctions"] = 1017] = "DuotoneTransferFunctions";
            ImageResourceIdentifier[ImageResourceIdentifier["DuotoneImageInformation"] = 1018] = "DuotoneImageInformation";
            ImageResourceIdentifier[ImageResourceIdentifier["WhiteBlackValues"] = 1019] = "WhiteBlackValues";
            ImageResourceIdentifier[ImageResourceIdentifier["EPSOptions"] = 1021] = "EPSOptions";
            ImageResourceIdentifier[ImageResourceIdentifier["QuickMaskInformation"] = 1022] = "QuickMaskInformation";
            ImageResourceIdentifier[ImageResourceIdentifier["LayerStateInformation"] = 1024] = "LayerStateInformation";
            ImageResourceIdentifier[ImageResourceIdentifier["WorkingPath"] = 1025] = "WorkingPath";
            ImageResourceIdentifier[ImageResourceIdentifier["LayersGroupInformation"] = 1026] = "LayersGroupInformation";
            ImageResourceIdentifier[ImageResourceIdentifier["IPTCNAARecord"] = 1028] = "IPTCNAARecord";
            ImageResourceIdentifier[ImageResourceIdentifier["ImageMode"] = 1029] = "ImageMode";
            ImageResourceIdentifier[ImageResourceIdentifier["JPEGQualityPrivate"] = 1030] = "JPEGQualityPrivate";
            ImageResourceIdentifier[ImageResourceIdentifier["GridAndGuidesInformation"] = 1032] = "GridAndGuidesInformation";
            ImageResourceIdentifier[ImageResourceIdentifier["DeprecatedThumbnailResource"] = 1033] = "DeprecatedThumbnailResource";
            ImageResourceIdentifier[ImageResourceIdentifier["CopyrightFlag"] = 1034] = "CopyrightFlag";
            ImageResourceIdentifier[ImageResourceIdentifier["CopyrightURL"] = 1035] = "CopyrightURL";
            ImageResourceIdentifier[ImageResourceIdentifier["ThumbnailResource"] = 1036] = "ThumbnailResource";
            ImageResourceIdentifier[ImageResourceIdentifier["GlobalAngle"] = 1037] = "GlobalAngle";
            ImageResourceIdentifier[ImageResourceIdentifier["DeprecatedColorSamplersResource"] = 1038] = "DeprecatedColorSamplersResource";
            ImageResourceIdentifier[ImageResourceIdentifier["ICCProfile"] = 1039] = "ICCProfile";
            ImageResourceIdentifier[ImageResourceIdentifier["Watermark"] = 1040] = "Watermark";
            ImageResourceIdentifier[ImageResourceIdentifier["ICCUntaggedProfile"] = 1041] = "ICCUntaggedProfile";
            ImageResourceIdentifier[ImageResourceIdentifier["EffectsVisible"] = 1042] = "EffectsVisible";
            ImageResourceIdentifier[ImageResourceIdentifier["SpotHalftone"] = 1043] = "SpotHalftone";
            ImageResourceIdentifier[ImageResourceIdentifier["DocumentSpecificIDsSeedNumber"] = 1044] = "DocumentSpecificIDsSeedNumber";
            ImageResourceIdentifier[ImageResourceIdentifier["UnicodeAlphaNames"] = 1045] = "UnicodeAlphaNames";
            ImageResourceIdentifier[ImageResourceIdentifier["IndexedColorTableCount"] = 1046] = "IndexedColorTableCount";
            ImageResourceIdentifier[ImageResourceIdentifier["TransparencyIndex"] = 1047] = "TransparencyIndex";
            ImageResourceIdentifier[ImageResourceIdentifier["GlobalAltitude"] = 1049] = "GlobalAltitude";
            ImageResourceIdentifier[ImageResourceIdentifier["Slices"] = 1050] = "Slices";
            ImageResourceIdentifier[ImageResourceIdentifier["WorkflowURL"] = 1051] = "WorkflowURL";
            ImageResourceIdentifier[ImageResourceIdentifier["JumpToXPEP"] = 1052] = "JumpToXPEP";
            ImageResourceIdentifier[ImageResourceIdentifier["AlphaIdentifiers"] = 1053] = "AlphaIdentifiers";
            ImageResourceIdentifier[ImageResourceIdentifier["URLList"] = 1054] = "URLList";
            ImageResourceIdentifier[ImageResourceIdentifier["VersionInfo"] = 1057] = "VersionInfo";
            ImageResourceIdentifier[ImageResourceIdentifier["EXIFData1"] = 1058] = "EXIFData1";
            ImageResourceIdentifier[ImageResourceIdentifier["EXIFData3"] = 1059] = "EXIFData3";
            ImageResourceIdentifier[ImageResourceIdentifier["XMPMetadata"] = 1060] = "XMPMetadata";
            ImageResourceIdentifier[ImageResourceIdentifier["CaptionDigest"] = 1061] = "CaptionDigest";
            ImageResourceIdentifier[ImageResourceIdentifier["PrintScale"] = 1062] = "PrintScale";
            ImageResourceIdentifier[ImageResourceIdentifier["PixelAspectRatio"] = 1064] = "PixelAspectRatio";
            ImageResourceIdentifier[ImageResourceIdentifier["LayerComps"] = 1065] = "LayerComps";
            ImageResourceIdentifier[ImageResourceIdentifier["UnusedAlternateDuotoneColors"] = 1066] = "UnusedAlternateDuotoneColors";
            ImageResourceIdentifier[ImageResourceIdentifier["AlternateSpotColors"] = 1067] = "AlternateSpotColors";
            ImageResourceIdentifier[ImageResourceIdentifier["LayerSelectionID"] = 1069] = "LayerSelectionID";
            ImageResourceIdentifier[ImageResourceIdentifier["HDRToningInformation"] = 1070] = "HDRToningInformation";
            ImageResourceIdentifier[ImageResourceIdentifier["PrintInfo"] = 1071] = "PrintInfo";
            ImageResourceIdentifier[ImageResourceIdentifier["LayerGroupsEnabledID"] = 1072] = "LayerGroupsEnabledID";
            ImageResourceIdentifier[ImageResourceIdentifier["ColorSamplersResource"] = 1073] = "ColorSamplersResource";
            ImageResourceIdentifier[ImageResourceIdentifier["MeasurementScale"] = 1074] = "MeasurementScale";
            ImageResourceIdentifier[ImageResourceIdentifier["TimelineInformation"] = 1075] = "TimelineInformation";
            ImageResourceIdentifier[ImageResourceIdentifier["SheetDisclosure"] = 1076] = "SheetDisclosure";
            ImageResourceIdentifier[ImageResourceIdentifier["DisplayInfoStructureFloatingPoint"] = 1077] = "DisplayInfoStructureFloatingPoint";
            ImageResourceIdentifier[ImageResourceIdentifier["OnionSkins"] = 1078] = "OnionSkins";
            ImageResourceIdentifier[ImageResourceIdentifier["CountInformation"] = 1080] = "CountInformation";
            ImageResourceIdentifier[ImageResourceIdentifier["PrintInformation"] = 1082] = "PrintInformation";
            ImageResourceIdentifier[ImageResourceIdentifier["PrintStyle"] = 1083] = "PrintStyle";
            ImageResourceIdentifier[ImageResourceIdentifier["MacintoshNSPrintInfo"] = 1084] = "MacintoshNSPrintInfo";
            ImageResourceIdentifier[ImageResourceIdentifier["WindowsDEVMODE"] = 1085] = "WindowsDEVMODE";
            ImageResourceIdentifier[ImageResourceIdentifier["AutoSaveFilePath"] = 1086] = "AutoSaveFilePath";
            ImageResourceIdentifier[ImageResourceIdentifier["AutoSaveFormat"] = 1087] = "AutoSaveFormat";
            ImageResourceIdentifier[ImageResourceIdentifier["PathSelectionState"] = 1088] = "PathSelectionState";
            ImageResourceIdentifier[ImageResourceIdentifier["ClippingPathName"] = 2999] = "ClippingPathName";
            ImageResourceIdentifier[ImageResourceIdentifier["OriginPathInfo"] = 3000] = "OriginPathInfo";
            ImageResourceIdentifier[ImageResourceIdentifier["ImageReadyVariables"] = 7000] = "ImageReadyVariables";
            ImageResourceIdentifier[ImageResourceIdentifier["ImageReadyDataSets"] = 7001] = "ImageReadyDataSets";
            ImageResourceIdentifier[ImageResourceIdentifier["LightroomWorkflow"] = 8000] = "LightroomWorkflow";
            ImageResourceIdentifier[ImageResourceIdentifier["PrintFlagsInformation"] = 10000] = "PrintFlagsInformation";
        })(ImageBlockDefinitions.ImageResourceIdentifier || (ImageBlockDefinitions.ImageResourceIdentifier = {}));
        var ImageResourceIdentifier = ImageBlockDefinitions.ImageResourceIdentifier;

        var ImageResourceBlock = (function () {
            function ImageResourceBlock() {
            }
            return ImageResourceBlock;
        })();
        ImageBlockDefinitions.ImageResourceBlock = ImageResourceBlock;
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var IndexedColorTableCount = (function (_super) {
            __extends(IndexedColorTableCount, _super);
            function IndexedColorTableCount() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1046;
            }
            return IndexedColorTableCount;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var IPTCNAARecord = (function (_super) {
            __extends(IPTCNAARecord, _super);
            function IPTCNAARecord() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1028;
            }
            return IPTCNAARecord;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var JPEGQualityPrivate = (function (_super) {
            __extends(JPEGQualityPrivate, _super);
            function JPEGQualityPrivate() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1030;
            }
            return JPEGQualityPrivate;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var JumpToXPEP = (function (_super) {
            __extends(JumpToXPEP, _super);
            function JumpToXPEP() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1052;
            }
            return JumpToXPEP;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var LayerComps = (function (_super) {
            __extends(LayerComps, _super);
            function LayerComps() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1065;
            }
            return LayerComps;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var LayerGroupsEnabledID = (function (_super) {
            __extends(LayerGroupsEnabledID, _super);
            function LayerGroupsEnabledID() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1072;
            }
            return LayerGroupsEnabledID;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var LayerSelectionID = (function (_super) {
            __extends(LayerSelectionID, _super);
            function LayerSelectionID() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1069;
            }
            return LayerSelectionID;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var LayersGroupInformation = (function (_super) {
            __extends(LayersGroupInformation, _super);
            function LayersGroupInformation() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1026;
            }
            return LayersGroupInformation;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var LayerStateInformation = (function (_super) {
            __extends(LayerStateInformation, _super);
            function LayerStateInformation() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1024;
            }
            return LayerStateInformation;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var LightroomWorkflow = (function (_super) {
            __extends(LightroomWorkflow, _super);
            function LightroomWorkflow() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 8000;
            }
            return LightroomWorkflow;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var MacintoshNSPrintInfo = (function (_super) {
            __extends(MacintoshNSPrintInfo, _super);
            function MacintoshNSPrintInfo() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1084;
            }
            return MacintoshNSPrintInfo;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var MacPrintMangerInfo = (function (_super) {
            __extends(MacPrintMangerInfo, _super);
            function MacPrintMangerInfo() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1001;
            }
            return MacPrintMangerInfo;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var MeasurementScale = (function (_super) {
            __extends(MeasurementScale, _super);
            function MeasurementScale() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1074;
            }
            return MeasurementScale;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var OnionSkins = (function (_super) {
            __extends(OnionSkins, _super);
            function OnionSkins() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1078;
            }
            return OnionSkins;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var OriginPathInfo = (function (_super) {
            __extends(OriginPathInfo, _super);
            function OriginPathInfo() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 3000;
            }
            return OriginPathInfo;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var PathSelectionState = (function (_super) {
            __extends(PathSelectionState, _super);
            function PathSelectionState() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1088;
            }
            return PathSelectionState;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var PixelAspectRatio = (function (_super) {
            __extends(PixelAspectRatio, _super);
            function PixelAspectRatio() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1064;
            }
            return PixelAspectRatio;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var PrintFlags = (function (_super) {
            __extends(PrintFlags, _super);
            function PrintFlags() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1011;
            }
            return PrintFlags;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var PrintFlagsInformation = (function (_super) {
            __extends(PrintFlagsInformation, _super);
            function PrintFlagsInformation() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 10000;
            }
            return PrintFlagsInformation;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var PrintInfo = (function (_super) {
            __extends(PrintInfo, _super);
            function PrintInfo() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1071;
            }
            return PrintInfo;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var PrintInformation = (function (_super) {
            __extends(PrintInformation, _super);
            function PrintInformation() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1082;
            }
            return PrintInformation;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var PrintScale = (function (_super) {
            __extends(PrintScale, _super);
            function PrintScale() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1062;
            }
            return PrintScale;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var PrintStyle = (function (_super) {
            __extends(PrintStyle, _super);
            function PrintStyle() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1083;
            }
            return PrintStyle;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var QuickMaskInformation = (function (_super) {
            __extends(QuickMaskInformation, _super);
            function QuickMaskInformation() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1022;
            }
            return QuickMaskInformation;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var ResolutionInfo = (function (_super) {
            __extends(ResolutionInfo, _super);
            function ResolutionInfo() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1005;
            }
            return ResolutionInfo;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var SheetDisclosure = (function (_super) {
            __extends(SheetDisclosure, _super);
            function SheetDisclosure() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1076;
            }
            return SheetDisclosure;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var Slices = (function (_super) {
            __extends(Slices, _super);
            function Slices() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1050;
            }
            return Slices;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var SpotHalftone = (function (_super) {
            __extends(SpotHalftone, _super);
            function SpotHalftone() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1043;
            }
            return SpotHalftone;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var ThumbnailResource = (function (_super) {
            __extends(ThumbnailResource, _super);
            function ThumbnailResource() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1036;
            }
            return ThumbnailResource;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var TimelineInformation = (function (_super) {
            __extends(TimelineInformation, _super);
            function TimelineInformation() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1075;
            }
            return TimelineInformation;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var TransparencyIndex = (function (_super) {
            __extends(TransparencyIndex, _super);
            function TransparencyIndex() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1047;
            }
            return TransparencyIndex;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var UnicodeAlphaNames = (function (_super) {
            __extends(UnicodeAlphaNames, _super);
            function UnicodeAlphaNames() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1045;
            }
            return UnicodeAlphaNames;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var UnusedAlternateDuotoneColors = (function (_super) {
            __extends(UnusedAlternateDuotoneColors, _super);
            function UnusedAlternateDuotoneColors() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1066;
            }
            return UnusedAlternateDuotoneColors;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var URLList = (function (_super) {
            __extends(URLList, _super);
            function URLList() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1054;
            }
            return URLList;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var VersionInfo = (function (_super) {
            __extends(VersionInfo, _super);
            function VersionInfo() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1057;
            }
            return VersionInfo;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var Watermark = (function (_super) {
            __extends(Watermark, _super);
            function Watermark() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1040;
            }
            return Watermark;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var WhiteBlackValues = (function (_super) {
            __extends(WhiteBlackValues, _super);
            function WhiteBlackValues() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1019;
            }
            return WhiteBlackValues;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var WindowsDEVMODE = (function (_super) {
            __extends(WindowsDEVMODE, _super);
            function WindowsDEVMODE() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1085;
            }
            return WindowsDEVMODE;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var WorkflowURL = (function (_super) {
            __extends(WorkflowURL, _super);
            function WorkflowURL() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1051;
            }
            return WorkflowURL;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var WorkingPath = (function (_super) {
            __extends(WorkingPath, _super);
            function WorkingPath() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1025;
            }
            return WorkingPath;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var XMPMetadata = (function (_super) {
            __extends(XMPMetadata, _super);
            function XMPMetadata() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1060;
            }
            return XMPMetadata;
        })(ImageBlockDefinitions.ImageResourceBlock);
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    var Psd = (function () {
        function Psd() {
            this.header = new Header();
            this.imageResourceBlocks = new Array();
        }
        return Psd;
    })();

    var ColorMode;
    (function (ColorMode) {
        ColorMode[ColorMode["Bitmap"] = 0] = "Bitmap";
        ColorMode[ColorMode["Grayscale"] = 1] = "Grayscale";
        ColorMode[ColorMode["Indexed"] = 2] = "Indexed";
        ColorMode[ColorMode["RGB"] = 3] = "RGB";
        ColorMode[ColorMode["CMYK"] = 4] = "CMYK";
        ColorMode[ColorMode["Multichannel"] = 7] = "Multichannel";
        ColorMode[ColorMode["Duotone"] = 8] = "Duotone";
        ColorMode[ColorMode["Lab"] = 9] = "Lab";
    })(ColorMode || (ColorMode = {}));

    var Header = (function () {
        function Header() {
        }
        return Header;
    })();

    var PsdLayer = (function () {
        function PsdLayer() {
        }
        return PsdLayer;
    })();
})(PSD || (PSD = {}));
var PSD;
(function (PSD) {
    var PsdLoader = (function () {
        function PsdLoader() {
        }
        PsdLoader.prototype.loadPSD = function (event) {
            var file = event.target.files[0];
            var reader = new FileReader();
            var psd = new Psd();
            var index = 0;
            var data;
            reader.onload = function () {
                data = new DataView(reader.result);
                psd.header.signature = readString(4);
                psd.header.version = readInt16();
                psd.header.reserved = 0;
                index += 6;
                psd.header.channels = readInt16();
                psd.header.height = readInt32();
                psd.header.width = readInt32();
                psd.header.depth = readInt16();
                psd.header.colorMode = readInt16();

                if (psd.header.colorMode == ColorMode.Indexed || psd.header.colorMode == ColorMode.Duotone) {
                    /*@todo load color data*/
                } else {
                    index += 4;
                }

                psd.imageResourcesSize = readInt32();
                var imageResourcesEndIndex = psd.imageResourcesSize + index;
                while (index < imageResourcesEndIndex) {
                    var newImageResourceBlock = new PSD.ImageBlockDefinitions.ImageResourceBlock();
                    newImageResourceBlock.signature = readString(4);
                    newImageResourceBlock.identifier = readInt16();
                    newImageResourceBlock.name = readPascalString();
                    newImageResourceBlock.blockSize = readInt32();

                    index += newImageResourceBlock.blockSize;
                    newImageResourceBlock.resourceData = index;
                    if (newImageResourceBlock.blockSize % 2 == 1)
                        index++;
                    psd.imageResourceBlocks.push(newImageResourceBlock);
                }

                psd.layerAndMaskSize = readInt32();

                debugger;
            };

            reader.readAsArrayBuffer(file);

            function readInt16() {
                var num = data.getInt16(index, false);
                index += 2;
                return num;
            }

            function readInt32() {
                var num = data.getInt32(index, false);
                index += 4;
                return num;
            }

            function readInt8() {
                return data.getInt8(index++);
            }

            function readString(length) {
                var retstr = "";
                for (var x = 0; x < length; x++) {
                    retstr += String.fromCharCode(readInt8());
                }
                return retstr;
            }

            function readPascalString() {
                var retstr = "";
                length = readInt8();
                if (length == 0) {
                    index++;
                    return "";
                }
                for (var x = 0; x < length; x++) {
                    retstr += String.fromCharCode(readInt8());
                }
                return retstr;
            }
        };
        return PsdLoader;
    })();
})(PSD || (PSD = {}));
//# sourceMappingURL=PSDLibrary.js.map
