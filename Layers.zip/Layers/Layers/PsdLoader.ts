﻿module PSD {
    class PsdLoader {
        loadPSD(event: Event) {


            var file: File = (<HTMLInputElement>event.target).files[0];
            var reader: FileReader = new FileReader();
            var psd: Psd = new Psd();
            var index: number = 0;
            var data: DataView;
            reader.onload = () => {
                data = new DataView(reader.result);
                psd.header.signature = readString(4);
                psd.header.version = readInt16();
                psd.header.reserved = 0;
                index += 6;
                psd.header.channels = readInt16();
                psd.header.height = readInt32();
                psd.header.width = readInt32();
                psd.header.depth = readInt16();
                psd.header.colorMode = readInt16();

                if (psd.header.colorMode == ColorMode.Indexed || psd.header.colorMode == ColorMode.Duotone) {
                    /*@todo load color data*/
                } else {
                    index += 4;
                }

                psd.imageResourcesSize = readInt32();
                var imageResourcesEndIndex: number = psd.imageResourcesSize + index;
                while (index < imageResourcesEndIndex) {
                    var newImageResourceBlock: PSD.ImageBlockDefinitions.ImageResourceBlock = new PSD.ImageBlockDefinitions.ImageResourceBlock();
                    newImageResourceBlock.signature = readString(4);
                    newImageResourceBlock.identifier = readInt16();
                    newImageResourceBlock.name = readPascalString();
                    newImageResourceBlock.blockSize = readInt32();

                    index += newImageResourceBlock.blockSize;
                    newImageResourceBlock.resourceData = index;
                    if (newImageResourceBlock.blockSize % 2 == 1) index++;
                    psd.imageResourceBlocks.push(newImageResourceBlock);
                }


                psd.layerAndMaskSize = readInt32();

                debugger;





            }

        reader.readAsArrayBuffer(file);

            function readInt16() {
                var num: number = data.getInt16(index, false);
                index += 2;
                return num;
            }

            function readInt32() {
                var num: number = data.getInt32(index, false);
                index += 4;
                return num;
            }

            function readInt8() {
                return data.getInt8(index++);

            }

            function readString(length: number) {
                var retstr = "";
                for (var x = 0; x < length; x++) {
                    retstr += String.fromCharCode(readInt8());
                }
                return retstr;
            }

            function readPascalString(): string {
                var retstr = "";
                length = readInt8();
                if (length == 0) {
                    index++;
                    return "";
                }
                for (var x = 0; x < length; x++) {
                    retstr += String.fromCharCode(readInt8());
                }
                return retstr;
            }



        }
    }
}