module PSD.ImageBlockDefinitions {
    class URLList extends ImageResourceBlock {
        BlockIdentifier = 1054; 
    } 
} 
