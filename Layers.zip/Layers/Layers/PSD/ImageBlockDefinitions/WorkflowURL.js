var __extends = this.__extends || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var WorkflowURL = (function (_super) {
            __extends(WorkflowURL, _super);
            function WorkflowURL() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1051;
            }
            return WorkflowURL;
        })(ImageBlockDefinitions.ImageResourceBlock);
        ImageBlockDefinitions.WorkflowURL = WorkflowURL;
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
//# sourceMappingURL=WorkflowURL.js.map
