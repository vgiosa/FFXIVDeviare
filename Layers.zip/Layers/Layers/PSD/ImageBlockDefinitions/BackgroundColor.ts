module PSD.ImageBlockDefinitions {
    class BackgroundColor extends ImageResourceBlock {
        BlockIdentifier = 1010; 
    } 
} 
