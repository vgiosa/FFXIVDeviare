module PSD.ImageBlockDefinitions {
    class AlphaIdentifiers extends ImageResourceBlock {
        BlockIdentifier = 1053; 
    } 
} 
