module PSD.ImageBlockDefinitions {
    class AutoSaveFormat extends ImageResourceBlock {
        BlockIdentifier = 1087; 
    } 
} 
