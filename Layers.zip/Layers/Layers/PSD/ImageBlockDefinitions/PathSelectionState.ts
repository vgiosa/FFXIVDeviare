module PSD.ImageBlockDefinitions {
    class PathSelectionState extends ImageResourceBlock {
        BlockIdentifier = 1088; 
    } 
} 
