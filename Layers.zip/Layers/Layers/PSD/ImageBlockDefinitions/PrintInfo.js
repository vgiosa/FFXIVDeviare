var __extends = this.__extends || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var PrintInfo = (function (_super) {
            __extends(PrintInfo, _super);
            function PrintInfo() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1071;
            }
            return PrintInfo;
        })(ImageBlockDefinitions.ImageResourceBlock);
        ImageBlockDefinitions.PrintInfo = PrintInfo;
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
//# sourceMappingURL=PrintInfo.js.map
