module PSD.ImageBlockDefinitions {
    class ICCUntaggedProfile extends ImageResourceBlock {
        BlockIdentifier = 1041; 
    } 
} 
