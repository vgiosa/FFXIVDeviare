module PSD.ImageBlockDefinitions {
    class PrintFlagsInformation extends ImageResourceBlock {
        BlockIdentifier = 10000; 
    } 
} 
