module PSD.ImageBlockDefinitions {
    class OnionSkins extends ImageResourceBlock {
        BlockIdentifier = 1078; 
    } 
} 
