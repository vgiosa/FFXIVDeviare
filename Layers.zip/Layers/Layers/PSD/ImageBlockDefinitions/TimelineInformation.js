var __extends = this.__extends || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var TimelineInformation = (function (_super) {
            __extends(TimelineInformation, _super);
            function TimelineInformation() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1075;
            }
            return TimelineInformation;
        })(ImageBlockDefinitions.ImageResourceBlock);
        ImageBlockDefinitions.TimelineInformation = TimelineInformation;
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
//# sourceMappingURL=TimelineInformation.js.map
