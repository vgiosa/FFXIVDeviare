module PSD.ImageBlockDefinitions {
    class PrintInfo extends ImageResourceBlock {
        BlockIdentifier = 1071; 
    } 
} 
