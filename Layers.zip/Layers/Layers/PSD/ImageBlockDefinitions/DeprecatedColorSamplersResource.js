var __extends = this.__extends || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var DeprecatedColorSamplersResource = (function (_super) {
            __extends(DeprecatedColorSamplersResource, _super);
            function DeprecatedColorSamplersResource() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1038;
            }
            return DeprecatedColorSamplersResource;
        })(ImageBlockDefinitions.ImageResourceBlock);
        ImageBlockDefinitions.DeprecatedColorSamplersResource = DeprecatedColorSamplersResource;
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
//# sourceMappingURL=DeprecatedColorSamplersResource.js.map
