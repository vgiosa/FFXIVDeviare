module PSD.ImageBlockDefinitions {
    class GlobalAngle extends ImageResourceBlock {
        BlockIdentifier = 1037; 
    } 
} 
