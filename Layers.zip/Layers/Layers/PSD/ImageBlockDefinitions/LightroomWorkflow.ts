module PSD.ImageBlockDefinitions {
    class LightroomWorkflow extends ImageResourceBlock {
        BlockIdentifier = 8000; 
    } 
} 
