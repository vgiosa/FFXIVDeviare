module PSD.ImageBlockDefinitions {
    class PrintInformation extends ImageResourceBlock {
        BlockIdentifier = 1082; 
    } 
} 
