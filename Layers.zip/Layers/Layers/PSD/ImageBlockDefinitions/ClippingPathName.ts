module PSD.ImageBlockDefinitions {
    class ClippingPathName extends ImageResourceBlock {
        BlockIdentifier = 2999; 
    } 
} 
