module PSD.ImageBlockDefinitions {
    class WorkingPath extends ImageResourceBlock {
        BlockIdentifier = 1025; 
    } 
} 
