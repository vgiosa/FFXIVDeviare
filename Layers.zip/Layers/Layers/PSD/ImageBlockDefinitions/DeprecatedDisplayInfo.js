var __extends = this.__extends || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var DeprecatedDisplayInfo = (function (_super) {
            __extends(DeprecatedDisplayInfo, _super);
            function DeprecatedDisplayInfo() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1007;
            }
            return DeprecatedDisplayInfo;
        })(ImageBlockDefinitions.ImageResourceBlock);
        ImageBlockDefinitions.DeprecatedDisplayInfo = DeprecatedDisplayInfo;
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
//# sourceMappingURL=DeprecatedDisplayInfo.js.map
