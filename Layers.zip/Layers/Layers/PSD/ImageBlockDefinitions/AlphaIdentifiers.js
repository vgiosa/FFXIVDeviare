var __extends = this.__extends || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var AlphaIdentifiers = (function (_super) {
            __extends(AlphaIdentifiers, _super);
            function AlphaIdentifiers() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1053;
            }
            return AlphaIdentifiers;
        })(ImageBlockDefinitions.ImageResourceBlock);
        ImageBlockDefinitions.AlphaIdentifiers = AlphaIdentifiers;
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
//# sourceMappingURL=AlphaIdentifiers.js.map
