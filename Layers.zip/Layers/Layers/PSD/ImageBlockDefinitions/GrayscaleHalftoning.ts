module PSD.ImageBlockDefinitions {
    class GrayscaleHalftoning extends ImageResourceBlock {
        BlockIdentifier = 1012; 
    } 
} 
