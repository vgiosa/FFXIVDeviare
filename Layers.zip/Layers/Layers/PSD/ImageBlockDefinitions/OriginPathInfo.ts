module PSD.ImageBlockDefinitions {
    class OriginPathInfo extends ImageResourceBlock {
        BlockIdentifier = 3000; 
    } 
} 
