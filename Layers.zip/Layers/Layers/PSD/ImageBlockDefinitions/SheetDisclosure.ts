module PSD.ImageBlockDefinitions {
    class SheetDisclosure extends ImageResourceBlock {
        BlockIdentifier = 1076; 
    } 
} 
