module PSD.ImageBlockDefinitions {
    class UnusedAlternateDuotoneColors extends ImageResourceBlock {
        BlockIdentifier = 1066; 
    } 
} 
