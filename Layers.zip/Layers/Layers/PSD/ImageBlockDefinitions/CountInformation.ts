module PSD.ImageBlockDefinitions {
    class CountInformation extends ImageResourceBlock {
        BlockIdentifier = 1080; 
    } 
} 
