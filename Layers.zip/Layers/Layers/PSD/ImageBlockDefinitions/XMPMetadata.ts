module PSD.ImageBlockDefinitions {
    class XMPMetadata extends ImageResourceBlock {
        BlockIdentifier = 1060; 
    } 
} 
