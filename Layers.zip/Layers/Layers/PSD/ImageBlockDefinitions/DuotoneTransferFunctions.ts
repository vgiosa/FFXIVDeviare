module PSD.ImageBlockDefinitions {
    class DuotoneTransferFunctions extends ImageResourceBlock {
        BlockIdentifier = 1017; 
    } 
} 
