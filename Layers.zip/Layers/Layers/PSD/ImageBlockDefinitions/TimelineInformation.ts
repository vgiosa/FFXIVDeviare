module PSD.ImageBlockDefinitions {
    class TimelineInformation extends ImageResourceBlock {
        BlockIdentifier = 1075; 
    } 
} 
