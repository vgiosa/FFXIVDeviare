module PSD.ImageBlockDefinitions {
    class DuotoneHalftoning extends ImageResourceBlock {
        BlockIdentifier = 1014; 
    } 
} 
