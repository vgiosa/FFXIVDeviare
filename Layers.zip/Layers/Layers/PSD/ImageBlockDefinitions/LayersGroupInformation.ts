module PSD.ImageBlockDefinitions {
    class LayersGroupInformation extends ImageResourceBlock {
        BlockIdentifier = 1026; 
    } 
} 
