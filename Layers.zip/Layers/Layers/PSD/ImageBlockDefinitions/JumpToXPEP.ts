module PSD.ImageBlockDefinitions {
    class JumpToXPEP extends ImageResourceBlock {
        BlockIdentifier = 1052; 
    } 
} 
