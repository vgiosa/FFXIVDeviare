module PSD.ImageBlockDefinitions {
    class MacPrintMangerInfo extends ImageResourceBlock {
        BlockIdentifier = 1001; 
    } 
} 
