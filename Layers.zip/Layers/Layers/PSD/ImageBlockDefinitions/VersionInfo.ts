module PSD.ImageBlockDefinitions {
    class VersionInfo extends ImageResourceBlock {
        BlockIdentifier = 1057; 
    } 
} 
