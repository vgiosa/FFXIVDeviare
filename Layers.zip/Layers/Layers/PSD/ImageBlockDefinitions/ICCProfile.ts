module PSD.ImageBlockDefinitions {
    class ICCProfile extends ImageResourceBlock {
        BlockIdentifier = 1039; 
    } 
} 
