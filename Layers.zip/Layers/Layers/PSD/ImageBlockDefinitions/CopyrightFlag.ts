module PSD.ImageBlockDefinitions {
    class CopyrightFlag extends ImageResourceBlock {
        BlockIdentifier = 1034; 
    } 
} 
