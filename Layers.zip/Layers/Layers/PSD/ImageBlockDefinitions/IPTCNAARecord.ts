module PSD.ImageBlockDefinitions {
    class IPTCNAARecord extends ImageResourceBlock {
        BlockIdentifier = 1028; 
    } 
} 
