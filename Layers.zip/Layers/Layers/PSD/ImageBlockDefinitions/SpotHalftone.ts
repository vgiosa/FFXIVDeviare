module PSD.ImageBlockDefinitions {
    class SpotHalftone extends ImageResourceBlock {
        BlockIdentifier = 1043; 
    } 
} 
