var __extends = this.__extends || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var PathSelectionState = (function (_super) {
            __extends(PathSelectionState, _super);
            function PathSelectionState() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1088;
            }
            return PathSelectionState;
        })(ImageBlockDefinitions.ImageResourceBlock);
        ImageBlockDefinitions.PathSelectionState = PathSelectionState;
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
//# sourceMappingURL=PathSelectionState.js.map
