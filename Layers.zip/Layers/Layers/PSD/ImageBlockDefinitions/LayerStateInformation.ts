module PSD.ImageBlockDefinitions {
    class LayerStateInformation extends ImageResourceBlock {
        BlockIdentifier = 1024; 
    } 
} 
