module PSD.ImageBlockDefinitions {
    class GlobalAltitude extends ImageResourceBlock {
        BlockIdentifier = 1049; 
    } 
} 
