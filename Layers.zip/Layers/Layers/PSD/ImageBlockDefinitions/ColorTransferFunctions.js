var __extends = this.__extends || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var ColorTransferFunctions = (function (_super) {
            __extends(ColorTransferFunctions, _super);
            function ColorTransferFunctions() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1016;
            }
            return ColorTransferFunctions;
        })(ImageBlockDefinitions.ImageResourceBlock);
        ImageBlockDefinitions.ColorTransferFunctions = ColorTransferFunctions;
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
//# sourceMappingURL=ColorTransferFunctions.js.map
