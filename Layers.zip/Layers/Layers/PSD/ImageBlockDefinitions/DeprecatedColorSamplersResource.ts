module PSD.ImageBlockDefinitions {
    class DeprecatedColorSamplersResource extends ImageResourceBlock {
        BlockIdentifier = 1038; 
    } 
} 
