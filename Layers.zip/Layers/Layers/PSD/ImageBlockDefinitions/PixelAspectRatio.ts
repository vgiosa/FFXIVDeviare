module PSD.ImageBlockDefinitions {
    class PixelAspectRatio extends ImageResourceBlock {
        BlockIdentifier = 1064; 
    } 
} 
