module PSD.ImageBlockDefinitions {
    class Watermark extends ImageResourceBlock {
        BlockIdentifier = 1040; 
    } 
} 
