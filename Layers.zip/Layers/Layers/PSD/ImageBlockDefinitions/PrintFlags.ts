module PSD.ImageBlockDefinitions {
    class PrintFlags extends ImageResourceBlock {
        BlockIdentifier = 1011; 
    } 
} 
