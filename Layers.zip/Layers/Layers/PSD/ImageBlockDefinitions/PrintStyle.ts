module PSD.ImageBlockDefinitions {
    class PrintStyle extends ImageResourceBlock {
        BlockIdentifier = 1083; 
    } 
} 
