module PSD.ImageBlockDefinitions {
    class EPSOptions extends ImageResourceBlock {
        BlockIdentifier = 1021; 
    } 
} 
