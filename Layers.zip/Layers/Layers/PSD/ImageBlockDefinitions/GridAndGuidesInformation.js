var __extends = this.__extends || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var GridAndGuidesInformation = (function (_super) {
            __extends(GridAndGuidesInformation, _super);
            function GridAndGuidesInformation() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1032;
            }
            return GridAndGuidesInformation;
        })(ImageBlockDefinitions.ImageResourceBlock);
        ImageBlockDefinitions.GridAndGuidesInformation = GridAndGuidesInformation;
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
//# sourceMappingURL=GridAndGuidesInformation.js.map
