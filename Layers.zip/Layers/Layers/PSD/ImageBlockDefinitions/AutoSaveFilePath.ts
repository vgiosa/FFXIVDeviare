module PSD.ImageBlockDefinitions {
    class AutoSaveFilePath extends ImageResourceBlock {
        BlockIdentifier = 1086; 
    } 
} 
