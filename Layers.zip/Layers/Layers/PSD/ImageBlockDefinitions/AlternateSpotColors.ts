module PSD.ImageBlockDefinitions {
    class AlternateSpotColors extends ImageResourceBlock {
        BlockIdentifier = 1067; 
    } 
} 
