var __extends = this.__extends || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var SpotHalftone = (function (_super) {
            __extends(SpotHalftone, _super);
            function SpotHalftone() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1043;
            }
            return SpotHalftone;
        })(ImageBlockDefinitions.ImageResourceBlock);
        ImageBlockDefinitions.SpotHalftone = SpotHalftone;
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
//# sourceMappingURL=SpotHalftone.js.map
