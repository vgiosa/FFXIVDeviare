module PSD.ImageBlockDefinitions {
    class Borderinformation extends ImageResourceBlock {
        BlockIdentifier = 1009; 
    } 
} 
