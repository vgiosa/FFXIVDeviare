module PSD.ImageBlockDefinitions {
    class JPEGQualityPrivate extends ImageResourceBlock {
        BlockIdentifier = 1030; 
    } 
} 
