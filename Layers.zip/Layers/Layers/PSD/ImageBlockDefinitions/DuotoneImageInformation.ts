module PSD.ImageBlockDefinitions {
    class DuotoneImageInformation extends ImageResourceBlock {
        BlockIdentifier = 1018; 
    } 
} 
