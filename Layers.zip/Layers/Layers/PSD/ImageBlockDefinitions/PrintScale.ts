module PSD.ImageBlockDefinitions {
    class PrintScale extends ImageResourceBlock {
        BlockIdentifier = 1062; 
    } 
} 
