module PSD.ImageBlockDefinitions {
    class DeprecatedThumbnailResource extends ImageResourceBlock {
        BlockIdentifier = 1033; 
    } 
} 
