module PSD.ImageBlockDefinitions {
    class IndexedColorTableCount extends ImageResourceBlock {
        BlockIdentifier = 1046; 
    } 
} 
