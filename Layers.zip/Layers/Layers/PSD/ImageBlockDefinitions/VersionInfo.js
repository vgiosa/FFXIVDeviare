var __extends = this.__extends || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var VersionInfo = (function (_super) {
            __extends(VersionInfo, _super);
            function VersionInfo() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1057;
            }
            return VersionInfo;
        })(ImageBlockDefinitions.ImageResourceBlock);
        ImageBlockDefinitions.VersionInfo = VersionInfo;
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
//# sourceMappingURL=VersionInfo.js.map
