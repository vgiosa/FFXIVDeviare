module PSD.ImageBlockDefinitions {
    class EXIFData1 extends ImageResourceBlock {
        BlockIdentifier = 1058; 
    } 
} 
