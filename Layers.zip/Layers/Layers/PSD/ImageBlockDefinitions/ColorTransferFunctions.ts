module PSD.ImageBlockDefinitions {
    class ColorTransferFunctions extends ImageResourceBlock {
        BlockIdentifier = 1016; 
    } 
} 
