module PSD.ImageBlockDefinitions {
    class ImageReadyVariables extends ImageResourceBlock {
        BlockIdentifier = 7000; 
    } 
} 
