module PSD.ImageBlockDefinitions {
    class UnicodeAlphaNames extends ImageResourceBlock {
        BlockIdentifier = 1045; 
    } 
} 
