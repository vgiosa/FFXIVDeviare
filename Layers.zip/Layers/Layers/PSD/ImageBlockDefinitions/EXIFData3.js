var __extends = this.__extends || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var EXIFData3 = (function (_super) {
            __extends(EXIFData3, _super);
            function EXIFData3() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1059;
            }
            return EXIFData3;
        })(ImageBlockDefinitions.ImageResourceBlock);
        ImageBlockDefinitions.EXIFData3 = EXIFData3;
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
//# sourceMappingURL=EXIFData3.js.map
