module PSD.ImageBlockDefinitions {
    class DocumentSpecificIDsSeedNumber extends ImageResourceBlock {
        BlockIdentifier = 1044; 
    } 
} 
