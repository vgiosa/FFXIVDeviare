module PSD.ImageBlockDefinitions {
    class WhiteBlackValues extends ImageResourceBlock {
        BlockIdentifier = 1019; 
    } 
} 
