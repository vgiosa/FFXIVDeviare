module PSD.ImageBlockDefinitions {
    class QuickMaskInformation extends ImageResourceBlock {
        BlockIdentifier = 1022; 
    } 
} 
