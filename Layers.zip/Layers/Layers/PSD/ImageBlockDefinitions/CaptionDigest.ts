module PSD.ImageBlockDefinitions {
    class CaptionDigest extends ImageResourceBlock {
        BlockIdentifier = 1061; 
    } 
} 
