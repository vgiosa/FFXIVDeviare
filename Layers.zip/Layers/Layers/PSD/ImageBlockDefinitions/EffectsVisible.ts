module PSD.ImageBlockDefinitions {
    class EffectsVisible extends ImageResourceBlock {
        BlockIdentifier = 1042; 
    } 
} 
