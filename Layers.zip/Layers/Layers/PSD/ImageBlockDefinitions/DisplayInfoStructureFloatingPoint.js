var __extends = this.__extends || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var DisplayInfoStructureFloatingPoint = (function (_super) {
            __extends(DisplayInfoStructureFloatingPoint, _super);
            function DisplayInfoStructureFloatingPoint() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1077;
            }
            return DisplayInfoStructureFloatingPoint;
        })(ImageBlockDefinitions.ImageResourceBlock);
        ImageBlockDefinitions.DisplayInfoStructureFloatingPoint = DisplayInfoStructureFloatingPoint;
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
//# sourceMappingURL=DisplayInfoStructureFloatingPoint.js.map
