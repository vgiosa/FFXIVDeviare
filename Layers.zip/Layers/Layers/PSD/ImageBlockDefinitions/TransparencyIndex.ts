module PSD.ImageBlockDefinitions {
    class TransparencyIndex extends ImageResourceBlock {
        BlockIdentifier = 1047; 
    } 
} 
