var __extends = this.__extends || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var LayerStateInformation = (function (_super) {
            __extends(LayerStateInformation, _super);
            function LayerStateInformation() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1024;
            }
            return LayerStateInformation;
        })(ImageBlockDefinitions.ImageResourceBlock);
        ImageBlockDefinitions.LayerStateInformation = LayerStateInformation;
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
//# sourceMappingURL=LayerStateInformation.js.map
