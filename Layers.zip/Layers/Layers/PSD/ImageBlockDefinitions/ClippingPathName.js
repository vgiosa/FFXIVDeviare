var __extends = this.__extends || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var ClippingPathName = (function (_super) {
            __extends(ClippingPathName, _super);
            function ClippingPathName() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 2999;
            }
            return ClippingPathName;
        })(ImageBlockDefinitions.ImageResourceBlock);
        ImageBlockDefinitions.ClippingPathName = ClippingPathName;
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
//# sourceMappingURL=ClippingPathName.js.map
