var __extends = this.__extends || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var CaptionDigest = (function (_super) {
            __extends(CaptionDigest, _super);
            function CaptionDigest() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1061;
            }
            return CaptionDigest;
        })(ImageBlockDefinitions.ImageResourceBlock);
        ImageBlockDefinitions.CaptionDigest = CaptionDigest;
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
//# sourceMappingURL=CaptionDigest.js.map
