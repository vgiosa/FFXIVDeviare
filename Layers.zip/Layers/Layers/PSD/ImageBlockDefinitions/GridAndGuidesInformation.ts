module PSD.ImageBlockDefinitions {
    class GridAndGuidesInformation extends ImageResourceBlock {
        BlockIdentifier = 1032; 
    } 
} 
