var __extends = this.__extends || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var IndexedColorTableCount = (function (_super) {
            __extends(IndexedColorTableCount, _super);
            function IndexedColorTableCount() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1046;
            }
            return IndexedColorTableCount;
        })(ImageBlockDefinitions.ImageResourceBlock);
        ImageBlockDefinitions.IndexedColorTableCount = IndexedColorTableCount;
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
//# sourceMappingURL=IndexedColorTableCount.js.map
