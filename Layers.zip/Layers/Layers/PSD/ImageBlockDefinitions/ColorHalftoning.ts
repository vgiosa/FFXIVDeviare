module PSD.ImageBlockDefinitions {
    class ColorHalftoning extends ImageResourceBlock {
        BlockIdentifier = 1013; 
    } 
} 
