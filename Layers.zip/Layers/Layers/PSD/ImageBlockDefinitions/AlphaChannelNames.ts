module PSD.ImageBlockDefinitions {
    class AlphaChannelNames extends ImageResourceBlock {
        BlockIdentifier = 1006; 
    } 
} 
