module PSD.ImageBlockDefinitions {
    class ResolutionInfo extends ImageResourceBlock {
        BlockIdentifier = 1005; 
    } 
} 
