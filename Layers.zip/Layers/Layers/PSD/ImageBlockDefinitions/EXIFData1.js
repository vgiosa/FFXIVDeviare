var __extends = this.__extends || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var EXIFData1 = (function (_super) {
            __extends(EXIFData1, _super);
            function EXIFData1() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1058;
            }
            return EXIFData1;
        })(ImageBlockDefinitions.ImageResourceBlock);
        ImageBlockDefinitions.EXIFData1 = EXIFData1;
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
//# sourceMappingURL=EXIFData1.js.map
