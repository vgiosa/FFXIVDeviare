module PSD.ImageBlockDefinitions {
    class CaptionPascalString extends ImageResourceBlock {
        BlockIdentifier = 1008; 
    } 
} 
