module PSD.ImageBlockDefinitions {
    class MacintoshNSPrintInfo extends ImageResourceBlock {
        BlockIdentifier = 1084; 
    } 
} 
