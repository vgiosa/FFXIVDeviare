var __extends = this.__extends || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var LightroomWorkflow = (function (_super) {
            __extends(LightroomWorkflow, _super);
            function LightroomWorkflow() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 8000;
            }
            return LightroomWorkflow;
        })(ImageBlockDefinitions.ImageResourceBlock);
        ImageBlockDefinitions.LightroomWorkflow = LightroomWorkflow;
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
//# sourceMappingURL=LightroomWorkflow.js.map
