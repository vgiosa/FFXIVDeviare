module PSD.ImageBlockDefinitions {
    class GrayscaleMultichannelTransferFunction extends ImageResourceBlock {
        BlockIdentifier = 1015; 
    } 
} 
