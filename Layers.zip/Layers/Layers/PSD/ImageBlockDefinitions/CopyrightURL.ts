module PSD.ImageBlockDefinitions {
    export class CopyrightURL extends ImageResourceBlock {
        BlockIdentifier = 1035; 
    } 
} 
