module PSD.ImageBlockDefinitions {
    class DisplayInfoStructureFloatingPoint extends ImageResourceBlock {
        BlockIdentifier = 1077; 
    } 
} 
