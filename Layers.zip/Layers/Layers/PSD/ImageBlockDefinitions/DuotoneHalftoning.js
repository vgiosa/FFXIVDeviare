var __extends = this.__extends || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var DuotoneHalftoning = (function (_super) {
            __extends(DuotoneHalftoning, _super);
            function DuotoneHalftoning() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1014;
            }
            return DuotoneHalftoning;
        })(ImageBlockDefinitions.ImageResourceBlock);
        ImageBlockDefinitions.DuotoneHalftoning = DuotoneHalftoning;
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
//# sourceMappingURL=DuotoneHalftoning.js.map
