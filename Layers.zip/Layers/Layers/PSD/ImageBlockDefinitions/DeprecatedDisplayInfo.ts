module PSD.ImageBlockDefinitions {
    class DeprecatedDisplayInfo extends ImageResourceBlock {
        BlockIdentifier = 1007; 
    } 
} 
