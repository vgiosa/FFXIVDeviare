module PSD.ImageBlockDefinitions {
    class WorkflowURL extends ImageResourceBlock {
        BlockIdentifier = 1051; 
    } 
} 
