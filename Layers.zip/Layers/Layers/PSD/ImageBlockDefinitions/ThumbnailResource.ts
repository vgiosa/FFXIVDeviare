module PSD.ImageBlockDefinitions {
    class ThumbnailResource extends ImageResourceBlock {
        BlockIdentifier = 1036; 
    } 
} 
