module PSD.ImageBlockDefinitions {
    class ColorSamplersResource extends ImageResourceBlock {
        BlockIdentifier = 1073; 
    } 
} 
