module PSD.ImageBlockDefinitions {
    class MeasurementScale extends ImageResourceBlock {
        BlockIdentifier = 1074; 
    } 
} 
