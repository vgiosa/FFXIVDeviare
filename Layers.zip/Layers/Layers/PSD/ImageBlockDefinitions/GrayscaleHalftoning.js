var __extends = this.__extends || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
var PSD;
(function (PSD) {
    (function (ImageBlockDefinitions) {
        var GrayscaleHalftoning = (function (_super) {
            __extends(GrayscaleHalftoning, _super);
            function GrayscaleHalftoning() {
                _super.apply(this, arguments);
                this.BlockIdentifier = 1012;
            }
            return GrayscaleHalftoning;
        })(ImageBlockDefinitions.ImageResourceBlock);
        ImageBlockDefinitions.GrayscaleHalftoning = GrayscaleHalftoning;
    })(PSD.ImageBlockDefinitions || (PSD.ImageBlockDefinitions = {}));
    var ImageBlockDefinitions = PSD.ImageBlockDefinitions;
})(PSD || (PSD = {}));
//# sourceMappingURL=GrayscaleHalftoning.js.map
