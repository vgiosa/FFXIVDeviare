module PSD.ImageBlockDefinitions {
    class EXIFData3 extends ImageResourceBlock {
        BlockIdentifier = 1059; 
    } 
} 
