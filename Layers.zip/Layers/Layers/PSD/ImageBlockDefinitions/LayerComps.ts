module PSD.ImageBlockDefinitions {
    class LayerComps extends ImageResourceBlock {
        BlockIdentifier = 1065; 
    } 
} 
