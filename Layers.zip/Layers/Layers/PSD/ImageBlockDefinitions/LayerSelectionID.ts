module PSD.ImageBlockDefinitions {
    class LayerSelectionID extends ImageResourceBlock {
        BlockIdentifier = 1069; 
    } 
} 
