module PSD.ImageBlockDefinitions {
    class ImageReadyDataSets extends ImageResourceBlock {
        BlockIdentifier = 7001; 
    } 
} 
