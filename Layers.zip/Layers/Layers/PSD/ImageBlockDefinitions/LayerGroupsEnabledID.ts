module PSD.ImageBlockDefinitions {
    class LayerGroupsEnabledID extends ImageResourceBlock {
        BlockIdentifier = 1072; 
    } 
} 
