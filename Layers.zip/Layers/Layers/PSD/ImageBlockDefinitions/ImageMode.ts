module PSD.ImageBlockDefinitions {
    class ImageMode extends ImageResourceBlock {
        BlockIdentifier = 1029; 
    } 
} 
