module PSD.ImageBlockDefinitions {
    class WindowsDEVMODE extends ImageResourceBlock {
        BlockIdentifier = 1085; 
    } 
} 
