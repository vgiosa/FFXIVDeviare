module PSD.ImageBlockDefinitions {
    class HDRToningInformation extends ImageResourceBlock {
        BlockIdentifier = 1070; 
    } 
} 
