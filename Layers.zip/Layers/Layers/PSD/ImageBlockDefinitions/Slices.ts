module PSD.ImageBlockDefinitions {
    class Slices extends ImageResourceBlock {
        BlockIdentifier = 1050; 
    } 
} 
