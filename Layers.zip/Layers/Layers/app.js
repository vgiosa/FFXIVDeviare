﻿var Renderer = (function () {
    function Renderer(width, height) {
        this.layers = new Array();
        this.width = width;
        this.height = height;
        this.canvas = document.createElement("canvas");
        this.canvas.width = this.width;
        this.canvas.height = this.height;
        document.body.appendChild(this.canvas);
    }
    Renderer.prototype.addLayer = function () {
        var layer = new Layer(this.width, this.height);
        layer.imageData = this.canvas.getContext("2d").createImageData(this.width, this.height);
        layer.drawRandomColorBar(this.layers.length);
        this.layers.push(layer);
        layer.opacity = 127;
    };

    Renderer.prototype.render = function () {
        var renderData = this.canvas.getContext("2d").createImageData(this.width, this.height);
        for (var il = 0; il < this.layers.length; il++) {
            var layer = this.layers[il];

            if (!layer.visible)
                continue;
            for (var iy = 0; iy < this.height; iy++) {
                for (var ix = 0; ix < this.width; ix++) {
                    var i = (iy * this.width + ix) * 4;
                    if (layer.imageData.data[i + 3] != 0) {
                        if ((layer.opacity == 255 && layer.imageData.data[i + 3] == 255)) {
                            renderData.data[i] = layer.imageData.data[i];
                            renderData.data[i + 1] = layer.imageData.data[i + 1];
                            renderData.data[i + 2] = layer.imageData.data[i + 2];
                            renderData.data[i + 3] = layer.imageData.data[i + 3];
                        } else {
                            var dstA = renderData.data[i] / 255;
                            var srcA = ((layer.opacity + layer.imageData.data[i + 3]) / 2) / 255;
                            var dstR = renderData.data[i];
                            var srcR = layer.imageData.data[i];
                            var dstB = renderData.data[i + 1];
                            var srcB = layer.imageData.data[i + 1];
                            var dstG = renderData.data[i + 2];
                            var srcG = layer.imageData.data[i + 2];
                            var outA = srcA + dstA * (1 - srcA);
                            renderData.data[i] = (srcR * srcA + dstR * dstA * (1 - srcA)) / outA;
                            renderData.data[i + 1] = (srcG * srcA + dstG * dstA * (1 - srcA)) / outA;
                            renderData.data[i + 2] = (srcB * srcA + dstB * dstA * (1 - srcA)) / outA;
                            renderData.data[i + 3] = outA * 255;
                        }
                    }
                }
            }
        }

        this.canvas.getContext("2d").putImageData(renderData, 0, 0);
    };
    return Renderer;
})();
var renderer;
window.onload = function () {
    var loader = new PSD.PsdLoader();

    document.getElementById("psdBox").onchange = loader.loadPSD;
    /*
    renderer = new Renderer(4000, 3000);
    renderer.addLayer();
    renderer.addLayer();
    renderer.addLayer();
    renderer.addLayer();
    renderer.addLayer();
    renderer.addLayer();
    renderer.addLayer();
    renderer.addLayer();
    renderer.addLayer();
    renderer.addLayer();
    renderer.layers[6].visible = false;
    renderer.render();
    */
};
//# sourceMappingURL=app.js.map
