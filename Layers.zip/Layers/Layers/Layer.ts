﻿class Layer {
    imageData: ImageData;
    width: number;
    height: number;
    visible: boolean = true;
    opacity: number = 255;
    constructor(width: number, height: number) {
        this.width = width;
        this.height = height;
    }


    /*mock data function*/
    drawRandomColorBar(offset?:number) {
        var r = Math.random() * 255;
        var g = Math.random() * 255;
        var b = Math.random() * 255;
        for (var iy = 0; iy < this.height; iy++) {
            for (var ix = 0 + (offset * 20); ix < 60 + (offset * 20); ix++) {
                var i = (iy * this.width + ix) * 4;
                this.imageData.data[i] = r;
                this.imageData.data[i + 1] = g;
                this.imageData.data[i + 2] = b;
                this.imageData.data[i + 3] = 255;
            }
        }
    }

}
     