﻿
module PSD {

    class Psd {
        header: Header = new Header();
        imageResourcesSize: number;
        imageResourceBlocks: Array<ImageBlockDefinitions.ImageResourceBlock> = new Array<ImageBlockDefinitions.ImageResourceBlock>();
        layerAndMaskSize: number;
        layerSize: number;
        layerCount: number;



    }


    enum ColorMode {
        Bitmap = 0,
        Grayscale = 1,
        Indexed = 2,
        RGB = 3,
        CMYK = 4,
        Multichannel = 7,
        Duotone = 8,
        Lab = 9
    }

    class Header {
        signature: string;
        version: number;
        reserved: number;
        channels: number;
        height: number;
        width: number;
        depth: number;
        colorMode: ColorMode;
    }



    class PsdLayer {

    }
}