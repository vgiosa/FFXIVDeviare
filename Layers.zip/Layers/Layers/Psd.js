﻿var PSD;
(function (PSD) {
    var Psd = (function () {
        function Psd() {
            this.header = new Header();
            this.imageResourceBlocks = new Array();
        }
        return Psd;
    })();
    PSD.Psd = Psd;

    (function (ColorMode) {
        ColorMode[ColorMode["Bitmap"] = 0] = "Bitmap";
        ColorMode[ColorMode["Grayscale"] = 1] = "Grayscale";
        ColorMode[ColorMode["Indexed"] = 2] = "Indexed";
        ColorMode[ColorMode["RGB"] = 3] = "RGB";
        ColorMode[ColorMode["CMYK"] = 4] = "CMYK";
        ColorMode[ColorMode["Multichannel"] = 7] = "Multichannel";
        ColorMode[ColorMode["Duotone"] = 8] = "Duotone";
        ColorMode[ColorMode["Lab"] = 9] = "Lab";
    })(PSD.ColorMode || (PSD.ColorMode = {}));
    var ColorMode = PSD.ColorMode;

    var Header = (function () {
        function Header() {
        }
        return Header;
    })();
    PSD.Header = Header;

    var PsdLayer = (function () {
        function PsdLayer() {
        }
        return PsdLayer;
    })();
    PSD.PsdLayer = PsdLayer;
})(PSD || (PSD = {}));
//# sourceMappingURL=Psd.js.map
