﻿var Layer = (function () {
    function Layer(width, height) {
        this.visible = true;
        this.opacity = 255;
        this.width = width;
        this.height = height;
    }
    /*mock data function*/
    Layer.prototype.drawRandomColorBar = function (offset) {
        var r = Math.random() * 255;
        var g = Math.random() * 255;
        var b = Math.random() * 255;
        for (var iy = 0; iy < this.height; iy++) {
            for (var ix = 0 + (offset * 20); ix < 60 + (offset * 20); ix++) {
                var i = (iy * this.width + ix) * 4;
                this.imageData.data[i] = r;
                this.imageData.data[i + 1] = g;
                this.imageData.data[i + 2] = b;
                this.imageData.data[i + 3] = 255;
            }
        }
    };
    return Layer;
})();
//# sourceMappingURL=Layer.js.map
